//
//  ViewController.m
//  stopwatchtutorial
//
//  Created by Yogesh Patel on 12/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize lblmin,lblsec,lblmili,strmili,strmin,strsec,strhistory,tableview,arrdata;
- (void)viewDidLoad {
    [super viewDidLoad];
    arrdata=[[NSMutableArray alloc]init];
    mili=0;
    sec=0;
    min=0;
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrdata.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableview dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    NSString *strdata=[arrdata objectAtIndex:indexPath.row];
    UILabel *label1=(UILabel *)[cell viewWithTag:1];
    label1.text=strdata;
    return  cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)helpermethod
{
    mili=mili+1;
    if (mili==100)
    {
        mili=0;
        sec=sec+1;
        if (sec==60)
        {
            sec=0;
            min=min+1;
        }
    }
    if (mili<10)
    {
        strmili=[NSString stringWithFormat:@"%i",mili];
    }
    else
    {
        strmili=[NSString stringWithFormat:@"%i",mili];
    }
    if (sec<10)
    {
        strsec=[NSString stringWithFormat:@"%i",sec];
    }
    else
    {
        strsec=[NSString stringWithFormat:@"%i",sec];
    }
    if (min<10)
    {
        strmin=[NSString stringWithFormat:@"%i",min];
    }
    else
    {
        strmin=[NSString stringWithFormat:@"%i",min];
    }
    lblmili.text=strmili;
    lblsec.text=strsec;
    lblmin.text=strmin;

}
- (IBAction)start:(id)sender
{
    timer=[NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(helpermethod) userInfo:nil repeats:YES];
}

- (IBAction)stop:(id)sender
{
    [timer invalidate];
}

- (IBAction)split:(id)sender
{
    strhistory=[NSString stringWithFormat:@"%@:%@:%@", strmin, strsec, strmili];
    [arrdata addObject:strhistory];
    [tableview reloadData];
}

- (IBAction)reset:(id)sender
{
    [timer invalidate];
    lblmili.text=@"00";
    lblsec.text=@"00";
    lblmin.text=@"00";
    [arrdata removeAllObjects];
    [tableview reloadData];
}
@end
