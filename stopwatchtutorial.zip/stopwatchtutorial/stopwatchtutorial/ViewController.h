//
//  ViewController.h
//  stopwatchtutorial
//
//  Created by Yogesh Patel on 12/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSTimer *timer;
    int mili;
    int sec;
    int min;
}

@property (strong, nonatomic) IBOutlet UILabel *lblmin;
@property (strong, nonatomic) IBOutlet UILabel *lblmili;
@property (strong, nonatomic) IBOutlet UILabel *lblsec;
- (IBAction)start:(id)sender;
- (IBAction)stop:(id)sender;
- (IBAction)split:(id)sender;
- (IBAction)reset:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *tableview;
@property(strong, nonatomic)NSMutableArray *arrdata;
@property(strong, nonatomic)NSString *strmili;
@property(strong, nonatomic)NSString *strsec;
@property(strong, nonatomic)NSString *strmin;
@property(strong, nonatomic)NSString *strhistory;


@end

